-- =========================================================
-- IDBCJ.org — RLS Test Scenarios
-- Manual verification script for the finance/attendance schema
-- =========================================================
-- HOW TO USE:
--   Run each scenario as the specified test user (Supabase lets you
--   impersonate a role/user in the SQL editor via `set local role`
--   and `set local request.jwt.claims`, or test via the app itself
--   by logging in as each account).
--
--   Each scenario states: SETUP -> ACTION -> EXPECTED RESULT.
--   "Dapat mabigo" = the insert/update should be REJECTED by RLS.
--   "Dapat gumana" = the action should SUCCEED.
-- =========================================================

-- ---------------------------------------------------------
-- TEST SETUP: create two locals and one secretary account each
-- ---------------------------------------------------------

insert into locals (id, name, timezone) values
  ('11111111-1111-1111-1111-111111111111', 'Local A - Fort McMurray', 'America/Edmonton'),
  ('22222222-2222-2222-2222-222222222222', 'Local B - Manila', 'Asia/Manila');

insert into members (id, local_id, full_name) values
  ('aaaaaaaa-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'Juan Dela Cruz'),
  ('bbbbbbbb-0000-0000-0000-000000000001', '22222222-2222-2222-2222-222222222222', 'Maria Santos');

-- secretary_a: secretary of Local A
insert into users (id, auth_user_id, member_id, local_id, role) values
  ('cccccccc-0000-0000-0000-000000000001', '<auth-uid-of-secretary-a>', 'aaaaaaaa-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'secretary');

-- secretary_b: secretary of Local B
insert into users (id, auth_user_id, member_id, local_id, role) values
  ('dddddddd-0000-0000-0000-000000000001', '<auth-uid-of-secretary-b>', 'bbbbbbbb-0000-0000-0000-000000000001', '22222222-2222-2222-2222-222222222222', 'secretary');

-- local_minister_a: oversight of Local A, supervising secretary_a
insert into users (id, auth_user_id, member_id, local_id, role, supervised_by) values
  ('eeeeeeee-0000-0000-0000-000000000001', '<auth-uid-of-minister-a>', null, '11111111-1111-1111-1111-111111111111', 'local_minister', null);

update users set supervised_by = 'eeeeeeee-0000-0000-0000-000000000001'
  where id = 'cccccccc-0000-0000-0000-000000000001';

-- pangasiwaan_user: church-wide oversight
insert into users (id, auth_user_id, member_id, local_id, role) values
  ('ffffffff-0000-0000-0000-000000000001', '<auth-uid-of-pangasiwaan>', null, '11111111-1111-1111-1111-111111111111', 'pangasiwaan');


-- =========================================================
-- SCENARIO 1 — Secretary A tries to insert Abuluyan for own local
-- Dapat gumana (own local, role = secretary)
-- =========================================================
-- Run as: secretary_a (auth.uid() = '<auth-uid-of-secretary-a>')

insert into abuluyan_totals (local_id, service_date, total_amount, recorded_by)
values ('11111111-1111-1111-1111-111111111111', '2026-09-27', 3500.00, 'cccccccc-0000-0000-0000-000000000001');

-- EXPECTED: 1 row inserted successfully.


-- =========================================================
-- SCENARIO 2 — Secretary A tries to insert Abuluyan for Local B
-- Dapat MABIGO (cross-local insert blocked by RLS)
-- =========================================================
-- Run as: secretary_a

insert into abuluyan_totals (local_id, service_date, total_amount, recorded_by)
values ('22222222-2222-2222-2222-222222222222', '2026-09-27', 5000.00, 'cccccccc-0000-0000-0000-000000000001');

-- EXPECTED: rejected — "new row violates row-level security policy
-- for table abuluyan_totals" (local_id not in secretary_a's own local_id).


-- =========================================================
-- SCENARIO 3 — Local Minister A tries to INSERT attendance
-- Dapat MABIGO (local_minister has no insert policy — read-only role)
-- =========================================================
-- Run as: local_minister_a

insert into attendance_records (member_id, local_id, service_date, service_type, present, recorded_by)
values ('aaaaaaaa-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-09-27', 'Linggo', true, 'eeeeeeee-0000-0000-0000-000000000001');

-- EXPECTED: rejected — no INSERT policy exists for local_minister role
-- on attendance_records (only 'secretary' has an insert policy).


-- =========================================================
-- SCENARIO 4 — Local Minister A tries to SELECT records of own local
-- Dapat gumana (read-only oversight of own local)
-- =========================================================
-- Run as: local_minister_a

select * from attendance_records where local_id = '11111111-1111-1111-1111-111111111111';

-- EXPECTED: returns rows (if any exist) — read access granted.


-- =========================================================
-- SCENARIO 5 — Local Minister A tries to SELECT records of Local B
-- Dapat MABIGO / walang laman (no access outside own local)
-- =========================================================
-- Run as: local_minister_a

select * from attendance_records where local_id = '22222222-2222-2222-2222-222222222222';

-- EXPECTED: returns ZERO rows (RLS silently filters them out —
-- this is normal Postgres RLS behavior: no error, just no matching rows).


-- =========================================================
-- SCENARIO 6 — Secretary A tries to edit a Submitted record
-- Dapat MABIGO (update policy only allows status = 'Draft')
-- =========================================================
-- Run as: secretary_a
-- Setup: assume a prior record was set to status = 'Submitted'

update abuluyan_totals
set total_amount = 9999.00
where local_id = '11111111-1111-1111-1111-111111111111'
  and status = 'Submitted';

-- EXPECTED: 0 rows updated — the USING clause requires status = 'Draft',
-- so Submitted rows are invisible to this UPDATE for a secretary.


-- =========================================================
-- SCENARIO 7 — Pangasiwaan user marks a Submitted record as Reviewed
-- Dapat gumana (pangasiwaan can update any record regardless of local/status)
-- =========================================================
-- Run as: pangasiwaan_user

update abuluyan_totals
set status = 'Reviewed'
where local_id = '11111111-1111-1111-1111-111111111111'
  and status = 'Submitted';

-- EXPECTED: row(s) updated successfully.


-- =========================================================
-- SCENARIO 8 — Pangasiwaan changes a member's status to "Pagtitiwalag"
-- Dapat gumana (only pangasiwaan has UPDATE policy on members)
-- =========================================================
-- Run as: pangasiwaan_user

update members
set status = 'Pagtitiwalag',
    status_changed_at = now(),
    status_changed_by = 'ffffffff-0000-0000-0000-000000000001',
    status_reason = 'halimbawa lang - internal reason'
where id = 'aaaaaaaa-0000-0000-0000-000000000001';

-- EXPECTED: row updated successfully.


-- =========================================================
-- SCENARIO 9 — Secretary A tries to change a member's status
-- Dapat MABIGO (secretary has no UPDATE policy on members table)
-- =========================================================
-- Run as: secretary_a

update members
set status = 'Inactive'
where id = 'bbbbbbbb-0000-0000-0000-000000000001';

-- EXPECTED: 0 rows updated — no UPDATE policy grants this to 'secretary'.


-- =========================================================
-- SCENARIO 10 — Insert Tulong sa Klase Ministeryal on a non-last-Sunday date
-- Dapat gumana pa rin — this is a SOFT rule (app-layer flag), not a hard
-- DB constraint, since exceptions to the "last Sunday" pattern are normal.
-- =========================================================
-- Run as: secretary_a
-- Use a date that is a Sunday but NOT the last Sunday of that month.

insert into member_collections (member_id, local_id, collection_type, amount, service_date, recorded_by, is_standard_schedule)
values ('aaaaaaaa-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111',
        'Tulong sa Klase Ministeryal', 200.00, '2026-09-06', 'cccccccc-0000-0000-0000-000000000001', false);

-- EXPECTED: 1 row inserted successfully. The app layer sets
-- is_standard_schedule = false since 2026-09-06 isn't the usual last Sunday —
-- this is informational only, not a block. The form/UI can show a
-- warning banner but must still allow submission.


-- =========================================================
-- SCENARIO 11 — Insert Tulong sa Klase Ministeryal on the actual last Sunday
-- Dapat gumana, at naka-flag bilang standard schedule
-- =========================================================
-- Run as: secretary_a

insert into member_collections (member_id, local_id, collection_type, amount, service_date, recorded_by, is_standard_schedule)
values ('aaaaaaaa-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111',
        'Tulong sa Klase Ministeryal', 200.00, '2026-09-27', 'cccccccc-0000-0000-0000-000000000001', true);

-- EXPECTED: 1 row inserted — 2026-09-27 IS the last Sunday of September 2026,
-- so is_standard_schedule = true.


-- =========================================================
-- CLEANUP (run after testing, to reset the sandbox)
-- =========================================================
-- delete from member_collections where local_id in ('11111111-1111-1111-1111-111111111111','22222222-2222-2222-2222-222222222222');
-- delete from abuluyan_totals where local_id in ('11111111-1111-1111-1111-111111111111','22222222-2222-2222-2222-222222222222');
-- delete from attendance_records where local_id in ('11111111-1111-1111-1111-111111111111','22222222-2222-2222-2222-222222222222');
-- delete from users where id in ('cccccccc-0000-0000-0000-000000000001','dddddddd-0000-0000-0000-000000000001','eeeeeeee-0000-0000-0000-000000000001','ffffffff-0000-0000-0000-000000000001');
-- delete from members where id in ('aaaaaaaa-0000-0000-0000-000000000001','bbbbbbbb-0000-0000-0000-000000000001');
-- delete from locals where id in ('11111111-1111-1111-1111-111111111111','22222222-2222-2222-2222-222222222222');

-- =========================================================
-- END OF TEST FILE
-- =========================================================
