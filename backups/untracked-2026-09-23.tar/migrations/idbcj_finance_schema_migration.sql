-- =========================================================
-- IDBCJ.org — Finance, Attendance & Membership Schema
-- Supabase / PostgreSQL migration
-- =========================================================
-- Notes:
--   * All "service_date" columns are LOCAL date (not UTC) —
--     the doctrinal rule is that Sunday worship is determined
--     by each local's own local time, not a global UTC day.
--     Store local_id-linked timezone on the `locals` table and
--     have the application layer resolve local date before insert.
--   * status flow across all encoding tables: Draft -> Submitted -> Reviewed
--   * Run this in order — later statements (RLS) depend on earlier tables.
-- =========================================================

-- ---------------------------------------------------------
-- ENUM TYPES
-- ---------------------------------------------------------
create type member_status as enum ('Active', 'Inactive', 'Pagtitiwalag');

create type app_role as enum ('secretary', 'local_minister', 'pangasiwaan');

create type record_status as enum ('Draft', 'Submitted', 'Reviewed');

create type service_type as enum (
  'Linggo',
  'New Year Thanksgiving',
  'Anniversary Thanksgiving',
  'Extra Thanksgiving',
  'Private Thanksgiving'
);

create type member_collection_type as enum (
  'Ambagan',
  'Tulong sa Klase Ministeryal'
);

-- ---------------------------------------------------------
-- CORE TABLES
-- ---------------------------------------------------------

create table locals (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  timezone text not null default 'Asia/Manila',  -- IANA tz name, per-local
  created_at timestamptz not null default now()
);

create table members (
  id uuid primary key default gen_random_uuid(),
  local_id uuid not null references locals(id),
  full_name text not null,
  status member_status not null default 'Active',
  status_changed_at timestamptz,
  status_changed_by uuid,  -- FK to users(id), added after users table exists
  status_reason text,
  created_at timestamptz not null default now()
);

-- users = login accounts (secretary / local_minister / pangasiwaan)
create table users (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid unique,        -- FK to Supabase auth.users(id)
  member_id uuid references members(id),
  local_id uuid not null references locals(id),
  role app_role not null,
  supervised_by uuid references users(id),  -- secretary -> local_minister
  created_at timestamptz not null default now()
);

-- back-fill FK now that users exists
alter table members
  add constraint members_status_changed_by_fkey
  foreign key (status_changed_by) references users(id);

create table thanksgiving_types (
  id uuid primary key default gen_random_uuid(),
  name text not null unique  -- New Year, Anniversary, Extra, Private
);

-- ---------------------------------------------------------
-- ATTENDANCE
-- ---------------------------------------------------------

create table attendance_records (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references members(id),
  local_id uuid not null references locals(id),
  service_date date not null,
  service_type service_type not null,
  present boolean not null default true,
  recorded_by uuid not null references users(id),
  status record_status not null default 'Draft',
  submitted_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- FINANCIAL: ABULUYAN (aggregate/anonymous, per local per Sunday)
-- ---------------------------------------------------------

create table abuluyan_totals (
  id uuid primary key default gen_random_uuid(),
  local_id uuid not null references locals(id),
  service_date date not null,
  total_amount numeric(12,2) not null check (total_amount >= 0),
  recorded_by uuid not null references users(id),
  status record_status not null default 'Draft',
  submitted_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- FINANCIAL: AMBAGAN + TULONG SA KLASE MINISTERYAL
-- (individual, secretary-recorded)
-- ---------------------------------------------------------

create table member_collections (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references members(id),
  local_id uuid not null references locals(id),
  collection_type member_collection_type not null,
  amount numeric(12,2) not null check (amount >= 0),
  service_date date not null,
  -- Tulong sa Klase Ministeryal: normal practice is once/month, last Sunday —
  -- but this is NOT a rigid rule (exceptions happen), so no DB-level CHECK
  -- constraint here. Flag it as a soft warning in the application/form layer
  -- instead (e.g. "Note: this date is not the usual last Sunday of the month").
  is_standard_schedule boolean,  -- app sets this: true if it matches the normal last-Sunday pattern, false/null if an exception
  recorded_by uuid not null references users(id),
  status record_status not null default 'Draft',
  submitted_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- FINANCIAL: THANKSGIVING OFFERINGS (individual, envelope-based)
-- ---------------------------------------------------------

create table thanksgiving_offerings (
  id uuid primary key default gen_random_uuid(),
  member_id uuid references members(id),  -- nullable: envelope name may not match a registered member
  given_name text not null,               -- name as written on the envelope
  local_id uuid not null references locals(id),
  thanksgiving_type_id uuid not null references thanksgiving_types(id),
  reason text not null,
  amount numeric(12,2) not null check (amount >= 0),
  service_date date not null,
  recorded_by uuid not null references users(id),
  status record_status not null default 'Draft',
  submitted_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- OPTIONAL: BATCH TRACKING for Klase Ministerial submissions
-- ---------------------------------------------------------

create table pangasiwaan_submissions (
  id uuid primary key default gen_random_uuid(),
  klase_ministerial_date date not null,
  submitted_by uuid not null references users(id),
  created_at timestamptz not null default now()
);

-- link column on each financial table (nullable until batched)
alter table abuluyan_totals add column submission_batch_id uuid references pangasiwaan_submissions(id);
alter table member_collections add column submission_batch_id uuid references pangasiwaan_submissions(id);
alter table thanksgiving_offerings add column submission_batch_id uuid references pangasiwaan_submissions(id);

-- ---------------------------------------------------------
-- INDEXES (for common queries: per local, per date, per member)
-- ---------------------------------------------------------

create index idx_attendance_local_date on attendance_records(local_id, service_date);
create index idx_attendance_member on attendance_records(member_id);

create index idx_abuluyan_local_date on abuluyan_totals(local_id, service_date);

create index idx_member_collections_local_date on member_collections(local_id, service_date);
create index idx_member_collections_member on member_collections(member_id);

create index idx_thanksgiving_local_date on thanksgiving_offerings(local_id, service_date);
create index idx_thanksgiving_member on thanksgiving_offerings(member_id);

create index idx_users_local on users(local_id);
create index idx_members_local on members(local_id);

-- =========================================================
-- ROW LEVEL SECURITY (RLS)
-- =========================================================
-- Assumes: Supabase auth.uid() maps to users.auth_user_id
-- Helper: a small function to fetch the caller's app-role row.
-- =========================================================

create or replace view my_user as
  select * from users where auth_user_id = auth.uid();

-- ---------------------------------------------------------
-- Enable RLS on all sensitive tables
-- ---------------------------------------------------------

alter table members enable row level security;
alter table attendance_records enable row level security;
alter table abuluyan_totals enable row level security;
alter table member_collections enable row level security;
alter table thanksgiving_offerings enable row level security;
alter table pangasiwaan_submissions enable row level security;

-- ---------------------------------------------------------
-- MEMBERS: secretary/local_minister can view own local;
-- only pangasiwaan can change status (Active/Inactive/Pagtitiwalag)
-- ---------------------------------------------------------

create policy members_select_own_local on members
  for select using (
    local_id in (select local_id from my_user)
    or exists (select 1 from my_user where role = 'pangasiwaan')
  );

create policy members_update_status_pangasiwaan_only on members
  for update using (
    exists (select 1 from my_user where role = 'pangasiwaan')
  );

-- ---------------------------------------------------------
-- ATTENDANCE_RECORDS
-- ---------------------------------------------------------

create policy attendance_select on attendance_records
  for select using (
    local_id in (select local_id from my_user)
    or exists (select 1 from my_user where role = 'pangasiwaan')
  );

create policy attendance_insert_secretary on attendance_records
  for insert with check (
    local_id in (select local_id from my_user where role = 'secretary')
  );

create policy attendance_update_secretary_draft_only on attendance_records
  for update using (
    status = 'Draft'
    and local_id in (select local_id from my_user where role = 'secretary')
  );

create policy attendance_update_pangasiwaan on attendance_records
  for update using (
    exists (select 1 from my_user where role = 'pangasiwaan')
  );

-- ---------------------------------------------------------
-- ABULUYAN_TOTALS  (same pattern as attendance)
-- ---------------------------------------------------------

create policy abuluyan_select on abuluyan_totals
  for select using (
    local_id in (select local_id from my_user)
    or exists (select 1 from my_user where role = 'pangasiwaan')
  );

create policy abuluyan_insert_secretary on abuluyan_totals
  for insert with check (
    local_id in (select local_id from my_user where role = 'secretary')
  );

create policy abuluyan_update_secretary_draft_only on abuluyan_totals
  for update using (
    status = 'Draft'
    and local_id in (select local_id from my_user where role = 'secretary')
  );

create policy abuluyan_update_pangasiwaan on abuluyan_totals
  for update using (
    exists (select 1 from my_user where role = 'pangasiwaan')
  );

-- ---------------------------------------------------------
-- MEMBER_COLLECTIONS (Ambagan + Tulong sa Klase Ministeryal)
-- ---------------------------------------------------------

create policy member_collections_select on member_collections
  for select using (
    local_id in (select local_id from my_user)
    or exists (select 1 from my_user where role = 'pangasiwaan')
  );

create policy member_collections_insert_secretary on member_collections
  for insert with check (
    local_id in (select local_id from my_user where role = 'secretary')
  );

create policy member_collections_update_secretary_draft_only on member_collections
  for update using (
    status = 'Draft'
    and local_id in (select local_id from my_user where role = 'secretary')
  );

create policy member_collections_update_pangasiwaan on member_collections
  for update using (
    exists (select 1 from my_user where role = 'pangasiwaan')
  );

-- ---------------------------------------------------------
-- THANKSGIVING_OFFERINGS
-- ---------------------------------------------------------

create policy thanksgiving_select on thanksgiving_offerings
  for select using (
    local_id in (select local_id from my_user)
    or exists (select 1 from my_user where role = 'pangasiwaan')
  );

create policy thanksgiving_insert_secretary on thanksgiving_offerings
  for insert with check (
    local_id in (select local_id from my_user where role = 'secretary')
  );

create policy thanksgiving_update_secretary_draft_only on thanksgiving_offerings
  for update using (
    status = 'Draft'
    and local_id in (select local_id from my_user where role = 'secretary')
  );

create policy thanksgiving_update_pangasiwaan on thanksgiving_offerings
  for update using (
    exists (select 1 from my_user where role = 'pangasiwaan')
  );

-- ---------------------------------------------------------
-- PANGASIWAAN_SUBMISSIONS — pangasiwaan only
-- ---------------------------------------------------------

create policy submissions_pangasiwaan_only on pangasiwaan_submissions
  for all using (
    exists (select 1 from my_user where role = 'pangasiwaan')
  );

-- =========================================================
-- SEED DATA (example — adjust to your actual locals/types)
-- =========================================================

insert into thanksgiving_types (name) values
  ('New Year Thanksgiving'),
  ('Anniversary Thanksgiving'),
  ('Extra Thanksgiving'),
  ('Private Thanksgiving');

-- =========================================================
-- END OF MIGRATION
-- =========================================================
