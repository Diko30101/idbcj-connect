# Plan B — Mga hakbang na may eksaktong code, bawat task

> Isinusulat ang bawat task **bago** ito gawin, at ipinapakita sa Admin para sa pag-apruba. Hindi ginagawa ang
> susunod na task hangga't hindi sumasagot ang Admin. Wala pang ia-apply sa production. Walang push maliban sa
> tahasang utos ng Admin (at sa `feature/giving-records` lang; hindi kailanman sa `main`, walang force-push).
> Mga tuntunin na nananatili: ang kumpirmasyon ng kaanib ay hindi mababawi sa app; ang database ang tunay na harang;
> walang default/suggested na halaga; walang "kulang"/"delinquent"; aalisin ang `placeholder="0.00"` ng Abuluyan.

Plano: `docs/superpowers/plans/2026-09-23-giving-records-app.md` · Spec: `docs/superpowers/specs/2026-09-23-giving-records-design.md`

---

## Task 1: Backup (bago ang anumang apply sa production)

**Layunin:** magkaroon ng (1) kopya ng lokal na git na hindi mawawala kahit magulo ang paglipat ng branch, (2) kopya ng
data at ng **estado ng schema** ng production bago ang 010–017, na **napatunayang eksakto** (hindi lang "nasulat"), at
(3) napatunayang **maibabalik** ang `financial_records` (ang tanging data na buburahin ng 015).

**Mga garantiya:**
- Ang lahat ng query sa production ay **SELECT lang** (walang `insert/update/delete/alter/set`), sa pamamagitan ng `execute_sql`.
- Walang production key/URL na ginagamit sa Docker. Ang Docker ay ginagamit lang para sa dalawang maikling pagsusuri (isang
  pansamantalang `postgres:17` na nabubura pagkatapos; ang imahe ay nasa makina na).
- Ang mga backup ay may **PII** (pangalan, email, telepono, kaarawan ng mga profile). Nasa `backups/` lamang (gitignored:
  `.gitignore:45 /backups`), hindi kokomit, hindi ipapadala kahit saan. Lalabas ang laman sa output ng tool sa sesyong ito.
- Walang pagbabago sa `origin`, walang push, walang pagbabago sa mga umiiral na commit.

**Files:**
- Gagawa (gitignored, sa `backups/`): `main-2026-09-23.bundle`, `untracked-2026-09-23.tar`, `backup_bago_010_2026-09-23.json`,
  `financial_records_2026-09-23.json`, `schema_snapshot_bago_010_2026-09-23.json`, `CHECKSUMS_2026-09-23.txt`
- Gagawa (kokomit): `migrations/scratch/verify_backup.sh`, `migrations/scratch/restore_drill.sh`
- Mga ref ng git: tag `backup-main-2026-09-23`, branch `backup/main-2026-09-23`

**Interfaces:**
- Produces: mga path at md5 sa itaas, na gagamitin ng Task 8 (015: pagbabalik ng `financial_records`), ng Plan A Task 4–6 (paghahambing
  ng schema pagkatapos ng rollback), at ng anumang production apply (ulitin ang Step 2–8 nang may bagong petsa **bago mismo** mag-apply).
- Consumes: wala.

- [ ] **Step 1: Suriin ang panimulang estado** (walang binabago)

```bash
cd /c/Users/Rodel/documents/idbcj-connect
git status -sb | head -1                 # inaasahan: ## main...origin/main [ahead 14, behind 48] (o kaunting iba dahil sa mga docs commit)
git log --oneline -1                     # inaasahan: 52957af (o mas bago) Add Plan B ...
git rev-parse main origin/main
ls backups/                              # inaasahan: backup_bago_008_migration_2026-09-23.json lang
docker version --format "{{.Server.Version}}"   # dapat may bersyon
docker images postgres:17 --format "{{.Repository}}:{{.Tag}} {{.Size}}"   # nasa makina na
```

- [ ] **Step 2: Git safety net** (mga ref lang; walang binabago sa mga commit o sa working tree)

```bash
cd /c/Users/Rodel/documents/idbcj-connect
git tag -a backup-main-2026-09-23 -m "Bago ang Plan B: lokal na main (mga commit na wala pa sa origin) 2026-09-23" main
git branch backup/main-2026-09-23 main
test "$(git rev-parse main)" = "$(git rev-parse 'backup-main-2026-09-23^{commit}')" \
  && test "$(git rev-parse main)" = "$(git rev-parse backup/main-2026-09-23)" \
  && echo "[OK] tugma ang main, tag, at branch"
# Kopya na hindi umaasa sa .git: bundle ng lahat ng commit na wala sa origin/main
git bundle create backups/main-2026-09-23.bundle origin/main..main
git bundle verify backups/main-2026-09-23.bundle
# Mga untracked na file (hindi pa nasa git; hindi kasama ang mga gitignored gaya ng node_modules at backups)
git ls-files --others --exclude-standard -z | tar --null -T - -cf backups/untracked-2026-09-23.tar
echo "bilang ng file sa tar: $(tar -tf backups/untracked-2026-09-23.tar | wc -l)"
git log --oneline origin/main..backup/main-2026-09-23 | wc -l        # bilang ng lokal na commit na protektado
```
Inaasahan: `[OK]`, `bundle ... is okay`, at ang bilang ng commit ay katumbas ng "ahead" sa Step 1.

- [ ] **Step 3: Backup ng DATA** — patakbuhin ang Query A sa `execute_sql` (project `azjkqqdrvbhhxogvdfye`). Ang resulta ay may dalawang column: `backup` (jsonb) at `backup_md5`.

```sql
select b as backup, md5(b::text) as backup_md5
from (
  select jsonb_build_object(
    'taken_at', now(),
    'project_ref', 'azjkqqdrvbhhxogvdfye',
    'note', 'Backup bago ang 010-017. Hindi kasama ang financial_records (hiwalay na file) at auth.users.',
    'counts', jsonb_build_object(
      'profiles', (select count(*) from public.profiles),
      'ministries', (select count(*) from public.ministries),
      'ministry_members', (select count(*) from public.ministry_members),
      'locals', (select count(*) from public.locals),
      'members', (select count(*) from public.members),
      'abuluyan_totals', (select count(*) from public.abuluyan_totals),
      'attendance_records', (select count(*) from public.attendance_records),
      'member_collections', (select count(*) from public.member_collections),
      'thanksgiving_offerings', (select count(*) from public.thanksgiving_offerings),
      'thanksgiving_types', (select count(*) from public.thanksgiving_types),
      'pangasiwaan_submissions', (select count(*) from public.pangasiwaan_submissions)
    ),
    'profiles', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.profiles t),
    'ministries', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.ministries t),
    'ministry_members', (select coalesce(jsonb_agg(to_jsonb(t) order by t.ministry_id, t.profile_id), '[]'::jsonb) from public.ministry_members t),
    'locals', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.locals t),
    'members', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.members t),
    'abuluyan_totals', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.abuluyan_totals t),
    'attendance_records', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.attendance_records t),
    'member_collections', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.member_collections t),
    'thanksgiving_offerings', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.thanksgiving_offerings t),
    'thanksgiving_types', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.thanksgiving_types t),
    'pangasiwaan_submissions', (select coalesce(jsonb_agg(to_jsonb(t) order by t.id), '[]'::jsonb) from public.pangasiwaan_submissions t)
  ) as b
) s;
```
Isulat ang halaga ng column na `backup` (ang JSON object lamang, hindi ang wrapper ng tool) sa
`C:\Users\Rodel\documents\idbcj-connect\backups\backup_bago_010_2026-09-23.json` gamit ang Write tool, **buo at hindi pinaikli**.
Itala ang `backup_md5` na ibinalik ng database. Sa Step 6 ay ihahambing ito sa md5 ng nasa file.

- [ ] **Step 4: Backup ng `financial_records`** (144 row; hiwalay) — Query B:

```sql
select b as backup, md5(b::text) as backup_md5
from (
  select jsonb_build_object(
    'taken_at', now(),
    'table', 'public.financial_records',
    'row_count', (select count(*) from public.financial_records),
    'sum_amount', (select coalesce(sum(amount), 0) from public.financial_records),
    'columns', (select jsonb_agg(column_name order by ordinal_position)
                from information_schema.columns
                where table_schema = 'public' and table_name = 'financial_records'),
    'rows', (select coalesce(jsonb_agg(to_jsonb(t) order by t.record_month, t.locality, t.category), '[]'::jsonb)
             from public.financial_records t)
  ) as b
) s;
```
Isulat ang `backup` sa `backups\financial_records_2026-09-23.json`. Itala ang `backup_md5`, `row_count` (inaasahan 144) at `sum_amount`.

- [ ] **Step 5: Snapshot ng SCHEMA** (para sa paghahambing pagkatapos ng anumang rollback) — Query C. Sakop lang ang mga table at function na
tatamaan o gagamitin ng 010–017: mga column, constraint, index, RLS, policy, grant (table at column), trigger (kasama ang sa `auth.users`),
mga function (kasama ang ACL), view, enum, extension, at cron job.

```sql
select b as backup, md5(b::text) as backup_md5
from (
  select jsonb_build_object(
    'taken_at', now(),
    'server_version', current_setting('server_version'),
    'scope', 'Mga bagay na tatamaan o babasahin ng 010-017. Para sa pagkukumpara pagkatapos ng rollback.',
    'extensions', (select jsonb_agg(jsonb_build_object('name', extname, 'version', extversion) order by extname) from pg_extension),
    'enums', (select jsonb_agg(jsonb_build_object('type', t.typname, 'labels', l.labels) order by t.typname)
              from pg_type t
              cross join lateral (select jsonb_agg(e.enumlabel order by e.enumsortorder) as labels from pg_enum e where e.enumtypid = t.oid) l
              where t.typnamespace = 'public'::regnamespace and t.typtype = 'e'),
    'columns', (select jsonb_agg(jsonb_build_object('table', c.table_name, 'column', c.column_name, 'type', c.udt_name,
                                                    'nullable', c.is_nullable, 'default', c.column_default)
                                 order by c.table_name, c.ordinal_position)
                from information_schema.columns c
                where c.table_schema = 'public'
                  and c.table_name in ('abuluyan_totals', 'attendance_records', 'members', 'ministry_members', 'profiles',
                                       'locals', 'ministries', 'member_collections', 'thanksgiving_offerings',
                                       'thanksgiving_types', 'pangasiwaan_submissions', 'financial_records')),
    'constraints', (select jsonb_agg(jsonb_build_object('table', conrelid::regclass::text, 'name', conname, 'def', pg_get_constraintdef(oid))
                                     order by conrelid::regclass::text, conname)
                    from pg_constraint
                    where connamespace = 'public'::regnamespace
                      and conrelid::regclass::text in ('abuluyan_totals', 'attendance_records', 'members', 'ministry_members', 'profiles',
                                                       'locals', 'ministries', 'member_collections', 'thanksgiving_offerings',
                                                       'thanksgiving_types', 'pangasiwaan_submissions', 'financial_records')),
    'indexes', (select jsonb_agg(jsonb_build_object('table', tablename, 'name', indexname, 'def', indexdef) order by tablename, indexname)
                from pg_indexes
                where schemaname = 'public'
                  and tablename in ('abuluyan_totals', 'attendance_records', 'members', 'ministry_members', 'profiles',
                                    'locals', 'ministries', 'member_collections', 'thanksgiving_offerings',
                                    'thanksgiving_types', 'pangasiwaan_submissions', 'financial_records')),
    'rls', (select jsonb_agg(jsonb_build_object('table', relname, 'enabled', relrowsecurity, 'forced', relforcerowsecurity) order by relname)
            from pg_class where relnamespace = 'public'::regnamespace and relkind = 'r'),
    'policies', (select jsonb_agg(jsonb_build_object('table', tablename, 'name', policyname, 'cmd', cmd, 'roles', roles::text,
                                                     'using', qual, 'check', with_check)
                                  order by tablename, policyname)
                 from pg_policies
                 where schemaname = 'public'
                   and tablename in ('abuluyan_totals', 'attendance_records', 'members', 'ministry_members', 'profiles',
                                     'locals', 'ministries', 'member_collections', 'thanksgiving_offerings',
                                     'thanksgiving_types', 'pangasiwaan_submissions', 'financial_records')),
    'table_grants', (select jsonb_agg(jsonb_build_object('table', table_name, 'grantee', grantee, 'privilege', privilege_type)
                                       order by table_name, grantee, privilege_type)
                     from information_schema.role_table_grants
                     where table_schema = 'public'
                       and grantee in ('anon', 'authenticated', 'service_role')
                       and table_name in ('abuluyan_totals', 'attendance_records', 'members', 'ministry_members', 'profiles',
                                          'locals', 'ministries', 'member_collections', 'thanksgiving_offerings',
                                          'thanksgiving_types', 'pangasiwaan_submissions', 'financial_records')),
    'column_grants', (select jsonb_agg(jsonb_build_object('table', table_name, 'column', column_name, 'grantee', grantee, 'privilege', privilege_type)
                                        order by table_name, column_name, grantee, privilege_type)
                      from information_schema.column_privileges
                      where table_schema = 'public'
                        and grantee in ('anon', 'authenticated')
                        and table_name in ('abuluyan_totals', 'attendance_records', 'members', 'ministry_members')),
    'triggers', (select jsonb_agg(jsonb_build_object('schema', n.nspname, 'table', c.relname, 'name', t.tgname, 'def', pg_get_triggerdef(t.oid))
                                   order by n.nspname, c.relname, t.tgname)
                 from pg_trigger t
                 join pg_class c on c.oid = t.tgrelid
                 join pg_namespace n on n.oid = c.relnamespace
                 where not t.tgisinternal
                   and ((n.nspname = 'public' and c.relname in ('abuluyan_totals', 'attendance_records', 'members', 'ministry_members',
                                                                'profiles', 'locals', 'ministries', 'member_collections',
                                                                'thanksgiving_offerings', 'thanksgiving_types',
                                                                'pangasiwaan_submissions', 'financial_records'))
                        or (n.nspname = 'auth' and c.relname = 'users'))),
    'functions', (select jsonb_agg(jsonb_build_object('name', p.proname, 'args', pg_get_function_identity_arguments(p.oid),
                                                      'acl', p.proacl::text, 'def', pg_get_functiondef(p.oid))
                                   order by p.proname, pg_get_function_identity_arguments(p.oid))
                  from pg_proc p
                  where p.pronamespace = 'public'::regnamespace
                    and p.prokind = 'f'
                    and p.proname in ('is_admin', 'is_staff', 'is_member', 'current_app_role', 'leads_ministry',
                                      'guard_profile_update', 'log_profile_change', 'handle_new_user',
                                      'sync_ministry_member_local_id', 'propagate_profile_local_id',
                                      'touch_financial_record_updated_at', 'send_weekly_local_finance_report')),
    'views', (select jsonb_agg(jsonb_build_object('name', viewname, 'def', definition) order by viewname)
              from pg_views where schemaname = 'public'),
    'cron_jobs', (select coalesce(jsonb_agg(jsonb_build_object('name', jobname, 'schedule', schedule, 'command', command, 'active', active)
                                            order by jobname), '[]'::jsonb)
                  from cron.job)
  ) as b
) s;
```
Isulat ang `backup` sa `backups\schema_snapshot_bago_010_2026-09-23.json` at itala ang `backup_md5`. Kung masyadong malaki ang output para sa
isang tawag, hahatiin ko ang Query C ayon sa susi (`columns`, `policies`, `functions`, atbp.) at pagsasamahin ang mga resulta sa isang file,
na may bagong md5 na kinuha ng database para sa pinagsamang jsonb (hindi ko huhulaan ang md5).

- [ ] **Step 6: Patunayang eksakto ang bawat file** (Docker, pansamantalang scratch Postgres na nabubura; walang koneksyon sa production)

Gagawa ng `migrations/scratch/verify_backup.sh` na may sumusunod na laman, at patatakbuhin ito para sa tatlong file:

```bash
#!/usr/bin/env bash
# =====================================================================
# Beripikahin na ang isang backup na JSON file ay eksaktong kapareho ng nasa database.
# Ang md5 ay kinuha ng PRODUCTION sa jsonb (backup::text); dito, ikinakarga ang file sa isang
# HIWALAY na Postgres (Docker, scratch) bilang jsonb at kinukuha ang parehong md5.
# Ang jsonb ay may kanonikal na anyo, kaya kung magkaiba ang laman (kahit isang character
# na nagkamali sa pagkopya) ay magkaiba ang md5.
#
# Gamit:  bash verify_backup.sh <file.json> <inaasahang_md5>
# Walang koneksyon sa production; walang secret.
# =====================================================================
set -uo pipefail
FILE="$1"; EXPECT="$2"
NAME=idbcj-pg-verify
DIR="$(cd "$(dirname "$FILE")" && pwd)"; BASE="$(basename "$FILE")"

docker rm -f "$NAME" >/dev/null 2>&1 || true
docker run -d --name "$NAME" -e POSTGRES_PASSWORD=verify "postgres:17" >/dev/null || { echo "[FAIL] hindi nasimulan ang container"; exit 2; }
trap 'docker rm -f "$NAME" >/dev/null 2>&1 || true' EXIT
for i in $(seq 1 120); do
  n=$(docker logs "$NAME" 2>&1 | grep -c "database system is ready to accept connections")
  [ "$n" -ge 2 ] && break
  sleep 1
done

( cd "$DIR" && docker cp "./$BASE" "$NAME:/tmp/backup.json" ) || { echo "[FAIL] hindi nakopya ang file"; exit 2; }
GOT=$(docker exec "$NAME" psql -U postgres -At -c "select md5((pg_read_file('/tmp/backup.json')::jsonb)::text)" 2>&1)
SIZE=$(docker exec "$NAME" psql -U postgres -At -c "select pg_size_pretty(length(pg_read_file('/tmp/backup.json'))::bigint)" 2>&1)
echo "file:      $BASE ($SIZE)"
echo "inaasahan: $EXPECT"
echo "nakuha:    $GOT"
if [ "$GOT" = "$EXPECT" ]; then echo "[OK] tugma ang md5: kapareho ng nasa database ang laman ng file"; else echo "[FAIL] hindi tugma"; exit 1; fi
```

```bash
cd /c/Users/Rodel/documents/idbcj-connect
bash migrations/scratch/verify_backup.sh backups/backup_bago_010_2026-09-23.json          <md5 mula sa Step 3>
bash migrations/scratch/verify_backup.sh backups/financial_records_2026-09-23.json        <md5 mula sa Step 4>
bash migrations/scratch/verify_backup.sh backups/schema_snapshot_bago_010_2026-09-23.json <md5 mula sa Step 5>
```
Inaasahan: `[OK] tugma ang md5` sa lahat. **Kapag may `[FAIL]`,** ang file ay hindi eksakto (nagkamali sa pagsulat): uulitin ko ang pagsulat ng file na iyon
at ang pagsusuri; hindi ako magpapatuloy hangga't hindi tugma.

- [ ] **Step 7: "Restore drill" ng `financial_records`** — patunayang maibabalik ang 144 row (ang daan pagkatapos ng 015). Scratch lang.

Gagawa ng `migrations/scratch/restore_drill.sh`:

```bash
#!/usr/bin/env bash
# =====================================================================
# "Restore drill" ng financial_records: patunayang MAIBABALIK ang 144 row mula sa JSON backup
# (ang landas ng pagbabalik pagkatapos ng 015). Ginagawa sa HIWALAY na scratch Postgres (Docker),
# hindi sa production. Ginagamit ang TOTOONG 008 mula sa repo para sa column na local_id.
#
# Gamit:  bash restore_drill.sh <financial_records_backup.json> <inaasahang_bilang> <inaasahang_kabuuan>
# Ang mga FK sa profiles ay lalaktawan (session_replication_role=replica) dahil wala ang
# mga profile sa scratch; ang CHECK at UNIQUE ay tinitingnan pa rin. Tinitiyak din na walang
# column sa JSON na wala sa table (hindi ito tahimik na mawawala).
# =====================================================================
set -uo pipefail
FILE="$1"; EXPECT_N="$2"; EXPECT_SUM="$3"
NAME=idbcj-pg-drill
ROOT="$(cd "$(dirname "$0")/../.." 2>/dev/null && pwd)"
[ -f "$ROOT/migrations/scratch/00_supabase_stub.sql" ] || ROOT="/c/Users/Rodel/documents/idbcj-connect"
DIR="$(cd "$(dirname "$FILE")" && pwd)"; BASE="$(basename "$FILE")"

docker rm -f "$NAME" >/dev/null 2>&1 || true
docker run -d --name "$NAME" -e POSTGRES_PASSWORD=drill postgres:17 >/dev/null || { echo "[FAIL] hindi nasimulan ang container"; exit 2; }
trap 'docker rm -f "$NAME" >/dev/null 2>&1 || true' EXIT
for i in $(seq 1 120); do
  n=$(docker logs "$NAME" 2>&1 | grep -c "database system is ready to accept connections")
  [ "$n" -ge 2 ] && break
  sleep 1
done
p() { docker exec -i "$NAME" psql -U postgres -X -q -v ON_ERROR_STOP=1 "$@"; }

p < "$ROOT/migrations/scratch/00_supabase_stub.sql" >/dev/null || { echo "[FAIL] stub"; exit 2; }
p < "$ROOT/supabase/008_locals_and_ministry_leader_constraint.sql" >/dev/null 2>&1 || { echo "[FAIL] 008"; exit 2; }
( cd "$DIR" && docker cp "./$BASE" "$NAME:/tmp/fr.json" ) || { echo "[FAIL] copy"; exit 2; }

echo "--- mga column sa JSON na wala sa table (dapat walang laman) ---"
p -At -c "select coalesce(string_agg(k, ','), '(wala)') from (select jsonb_array_elements_text((pg_read_file('/tmp/fr.json')::jsonb)->'columns') k except select column_name from information_schema.columns where table_schema='public' and table_name='financial_records') x"

echo "--- pagbabalik ---"
p -c "set session_replication_role = replica; insert into public.financial_records select * from jsonb_populate_recordset(null::public.financial_records, (pg_read_file('/tmp/fr.json')::jsonb)->'rows');" || { echo "[FAIL] pagbabalik"; exit 1; }

N=$(p -At -c "select count(*) from public.financial_records")
S=$(p -At -c "select coalesce(sum(amount), 0) from public.financial_records")
echo "bilang: inaasahan $EXPECT_N, nakuha $N"
echo "kabuuan: inaasahan $EXPECT_SUM, nakuha $S"
if [ "$N" = "$EXPECT_N" ] && [ "$(echo "$S" | tr -d ' ')" = "$(echo "$EXPECT_SUM" | tr -d ' ')" ]; then echo "[OK] naibalik ang lahat ng row at tugma ang kabuuan"; else echo "[FAIL] hindi tugma"; exit 1; fi
```

```bash
cd /c/Users/Rodel/documents/idbcj-connect
bash migrations/scratch/restore_drill.sh backups/financial_records_2026-09-23.json 144 <sum_amount mula sa Step 4>
```
Inaasahan: walang "column na wala sa table" (`(wala)`), `[OK] naibalik ang lahat ng row at tugma ang kabuuan`.

- [ ] **Step 8: Mga checksum at ulat**

```bash
cd /c/Users/Rodel/documents/idbcj-connect/backups
sha256sum main-2026-09-23.bundle untracked-2026-09-23.tar backup_bago_010_2026-09-23.json financial_records_2026-09-23.json schema_snapshot_bago_010_2026-09-23.json > CHECKSUMS_2026-09-23.txt
sha256sum -c CHECKSUMS_2026-09-23.txt
ls -l
cd .. && git check-ignore -v backups/backup_bago_010_2026-09-23.json && git status --short backups | head -2   # walang lalabas sa status (gitignored)
```
Ipapakita ko sa Admin: ang buong path ng bawat file, ang laki, ang mga bilang mula sa `counts`, ang mga md5, ang output ng verify at ng restore drill, at
ang listahan ng mga ref ng git. Ipapaalala ko na **kailangang ulitin ang Step 3–8 (bagong petsa sa pangalan ng file) bago mismo ang bawat production apply**,
at na ang mga file ay may PII: iminumungkahi kong kopyahin ang folder na `backups/` sa isang ligtas na lugar (hal. naka-encrypt na drive) — ikaw ang bahala.

- [ ] **Step 9: Commit (lokal)** ng mga script at ng dokumentong ito (walang push):

```bash
cd /c/Users/Rodel/documents/idbcj-connect
git add migrations/scratch/verify_backup.sh migrations/scratch/restore_drill.sh docs/superpowers/plans/2026-09-23-giving-records-app-tasks.md
git commit -m "Add backup verification and restore-drill scripts; Plan B Task 1 steps"
```

**Pamantayan ng pagtanggap (lahat ay dapat totoo):** (a) tugma ang md5 ng tatlong JSON; (b) `[OK]` ang restore drill (144 row, tugma ang kabuuan); (c) `bundle is okay`;
(d) tugma ang `main`, tag, at branch; (e) `sha256sum -c` ay OK; (f) walang file ng backup na tracked ng git; (g) walang binago sa production (mga SELECT lang) at walang push.

**Mga panganib ng task na ito:** (1) may error sa pagkopya ng malalaking JSON sa file → nahuhuli ng md5 na kinuha ng database; (2) ang snapshot ay maaaring magmukhang kumpleto pero kulang ang saklaw
→ malinaw ang listahan ng mga table/function sa Query C, at ang anumang bagay na tatamaan ng mga susunod na migration ngunit wala rito ay idadagdag bago ang production apply; (3) ang restore drill ay
hindi sumasakop sa FK papuntang `profiles` (nilaktawan) → sinasabi nang tahasan; ang CHECK at UNIQUE ay tinitingnan pa rin; (4) ang backup ay isang sandali lang → uulitin bago ang apply.
